//
//  BaoFooAuthorize.h
//  BaoFooAuthorize
//
//  Created by 路国良 on 16/5/10.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaoFooAuthorizeViewController.h"
//! Project version number for BaoFooAuthorize.
FOUNDATION_EXPORT double BaoFooAuthorizeVersionNumber;

//! Project version string for BaoFooAuthorize.
FOUNDATION_EXPORT const unsigned char BaoFooAuthorizeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BaoFooAuthorize/PublicHeader.h>


