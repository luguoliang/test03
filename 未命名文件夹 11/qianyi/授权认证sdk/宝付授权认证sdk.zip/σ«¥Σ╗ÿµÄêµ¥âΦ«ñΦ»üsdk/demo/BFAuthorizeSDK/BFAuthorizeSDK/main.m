//
//  main.m
//  BFAuthorizeSDK
//
//  Created by 路国良 on 16/5/9.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
